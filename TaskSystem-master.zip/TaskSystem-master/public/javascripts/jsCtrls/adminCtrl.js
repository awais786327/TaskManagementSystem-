angular.module('serverApp')
    .controller('adminCtrl',function($scope,$rootScope,$http ,$location){
        $scope.adminName =$rootScope.user.user.name;
        $scope.stdData=$rootScope.user.stdData;
        $scope.std={};
        $scope.std.subClass=1;
        $scope.giveTaskList=document.getElementById('giveTask');
        $scope.addStdForm=document.getElementById('addStdForm');
        $scope.showStd=document.getElementById('checkList');
        $scope.switchClass123=document.getElementById('switch');
        $scope.addStudentShowCard=function(){
            $scope.giveTaskList.style.display='none';
            $scope.showStd.style.display='none';
            $scope.addStdForm.style.display='block';
            $scope.switchClass123.style.display='none';
        };
        $scope.addStd=function(dataSend){
            $http.post('users/addStd',dataSend).success(function(data){
                $('#loginModal').modal('toggle');
                $scope.std = {};
                $scope.std.subClass = 1;
                //alert(data.message);
                $rootScope.user.stdData=data;
                $scope.stdData=data;
            })
                .error(function(data){
                    alert(data);
                    console.log(data);
                })
        };
        $scope.switchClass=function(){
            $scope.giveTaskList.style.display='none';
            $scope.showStd.style.display='none';
            $scope.addStdForm.style.display='none';
            $scope.switchClass123.style.display='block';
        };
        $scope.checkStdListShow=function(){
            $scope.giveTaskList.style.display='none';
            $scope.showStd.style.display='block';
            $scope.addStdForm.style.display='none';
            $scope.switchClass123.style.display='none';
        };
        $scope.saveClassChanged=function(idx){
            $http.post('users/switchClass',$scope.stdData[idx]).success(function(data){
                alert(data);
            })
                .error(function(data){
                    alert(data);
                    console.log(data);
                })
        };
        $scope.checkStdList=function(){
            $scope.giveTaskList.style.display='block';
            $scope.showStd.style.display='none';
            $scope.addStdForm.style.display='none';
            $scope.switchClass123.style.display='none';
        };
        $scope.giveTask=function(idx){
            $rootScope.giveTaskToThis = idx;
            $location.path('/giveTask');

        };
        $scope.commentOnTask=function(indx,com){
            if(!com){
                alert('Please Write Something!');
            }
            else{
                $scope.stdData[$rootScope.giveTaskToThis].tasks[indx].comments.push({data:com,commentor:'Admin'});
                console.log('admin cmnt', $scope.stdData, $scope.stdData[$rootScope.giveTaskToThis]);
                $http.post('users/taskComFromAdmin',$scope.stdData[$rootScope.giveTaskToThis]).success(function(datac){
                    console.log(datac);
                })
                    .error(function(data){
                        alert(data);
                        console.log(data);
                    })
            }
        };
        $scope.giveTask12=function(taskData){
            if(!taskData){
                alert('Please Write Something!');
            }
            else{
                $scope.stdData[$rootScope.giveTaskToThis].tasks.push({status:"InComplete",ratings:0,data:taskData,comments:[]});
                $http.post('users/giveTask',$scope.stdData[$rootScope.giveTaskToThis]).success(function(datat){
                    $('#taskModal').modal('toggle');
                    // alert(datat)
                })
                    .error(function(data){
                        alert(data);
                        console.log(data);
                    })
            }
        };
        $scope.getRatings=function(){
            $http.post('users/getRatings',$scope.stdData[$rootScope.giveTaskToThis]).success(function(datat){
                alert(datat);
            })
                .error(function(data){
                    alert(data);
                    console.log(data);
                })
        };
        $scope.logout=function(){
            $location.path('/')
        };
        $scope.removeStu=function(index){
            var stuArray, actualStudent;

            $http.get('users/getStu').success(function(data){
                stuArray = data;
                actualStudent = stuArray[index];
                console.log(actualStudent);

                $http.delete('users/removeStd/' + actualStudent._id).success(function (data) {
                    $('#removeModal').modal('toggle');
                    // alert('successfully removed!');
                    // location.reload();
                    $location.path('/adminPanel');

                    $rootScope.user.stdData=data;
                    $scope.stdData=data;

                }).error(function (err) {
                    alert('something went wrong!');
                });

            }).error(function(err){
                console.error(err);
            });

        };
    });