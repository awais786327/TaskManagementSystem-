angular.module('serverApp')
    .controller('stdCtrl',function($scope,$rootScope,$http,$location){
        $scope.thisStdData=$rootScope.thisStdData;
        $scope.commentOnTask=function(indx,com){
            $scope.comObj;
            if(!com){
                alert('Please Write Something!');
            }
            else{
                // var length = $scope.thisStdData.tasks[indx].comments.length;
                // $scope.comObj = $scope.thisStdData.tasks[indx].comments[length];
                $scope.thisStdData.tasks[indx].comments.push({data:com,commentor:$scope.thisStdData.name});
                // console.log($scope.thisStdData, $scope.thisStdData.tasks, $scope.thisStdData.tasks[indx], $scope.thisStdData.tasks[indx].comments);

                $http.post('users/taskComFromStd',$scope.thisStdData).success(function(datac){
                    console.log(datac)
                })
                    .error(function(data){
                        alert(data);
                        console.log(data);
                    })
            }
        };
        $scope.changeStatus=function(idx){
            if($scope.thisStdData.tasks[idx].status=='Completed'){
                $scope.thisStdData.tasks[idx].status='InComplete';
                $http.post('users/changeStatus',$scope.thisStdData).success(function(datac){
                alert(datac);
            })
                .error(function(data){
                    alert(data);
                    console.log(data);
                })
        }
            else{
                $scope.thisStdData.tasks[idx].status='Completed';
                $http.post('users/changeStatus',$scope.thisStdData).success(function(datac){
                    alert(datac);
                })
                    .error(function(data){
                        alert(data);
                        console.log(data);
                    })
            }
        };
        $scope.logout=function(){
            $location.path('/');
            // location.reload();

        };
    });