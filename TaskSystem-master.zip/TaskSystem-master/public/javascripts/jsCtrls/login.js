angular.module('serverApp')
.controller("loginCtrl",function($scope,$rootScope,$http,$location){
    var adminCheck = false;
    $rootScope.StuLoginCheck = false;
    $rootScope.adminCheck = adminCheck;
    $scope.login = function(user){
        $rootScope.StuLoginCheck = true;
            $http.post('users/loginStd',user).success(function(data){
                if(data ==false){
                    $rootScope.StuLoginCheck = false;
                    alert("Oops we can't find your Record :(");
                }
                else{
                    $rootScope.thisStdData = data[0];
                    $location.path('/studentHome');
                }

            })
                .error(function(data){
                    console.log(user);
                    console.log(data);
                })

        };
        $scope.adminLogin = function(user){
            if(user.name != 'admin' && user.password != 'admin'){
                alert("Please enter valid details");
            }
            else {
                $rootScope.adminCheck = true;
                $http.post('users/loginAdm',user).success(function(data){
                    $rootScope.adminCheck = false;
                    $rootScope.user = data;
                    $location.path('/adminPanel')
                })
                    .error(function(data){
                        console.log(user);
                        console.log(data);
                    });
            }
        };
    });