A barebones Node.js app using [Express 4](http://expressjs.com/).
Make sure you have [Node.js](http://nodejs.org/) 


[ ![Codeship Status for ishaq-bhojani/First-app](https://codeship.com/projects/bcb8e220-51f0-0132-5972-7a00f62ec16b/status)](https://codeship.com/projects/48482)


